
def f():
	s=""
	x = open("index.html","r")
	for line in x:
		i = 0;
		while i < len(line):
			if(line[i] == "\t"):
				s+="1"
			elif(i+7 < len(line) and line[i:i+7] == " "*7):
				i+=7
				s+="0"
			i+=1
	return s

print f()

